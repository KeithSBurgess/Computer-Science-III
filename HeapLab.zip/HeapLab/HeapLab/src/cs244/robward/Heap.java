package cs244.robward;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.NoSuchElementException;


public class Heap<Element extends Comparable<Element>> implements MinHeapInterface<Element> {

	private ArrayList<Element> elements = new ArrayList<>();
	private Comparator<Element> comparator = (E1, E2) -> (E1.compareTo(E2));
	public Heap() {
		super();
		elements.add(null); 
	}
	public Heap( Comparator<Element> comparator) {
		super();
		this.comparator = comparator ; 
		elements.add(null); 
	}
	@Override
	public void add(Element element) {
		
		elements.add(element); 
		percolateUp(elements.size()-1);
	}

	int percolateUp(int index)
	{
		
		
	}
	
	int percolatDown(int index)
	{
		
		
		
	}
	
	@Override
	public void clear() {
		elements = new ArrayList<>();
		elements.add(null);
		
	}

	@Override
	public Element get() {
		
		return peek();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return elements.size() == 1;
	}

	@Override
	public Element peek() {
		if(isEmpty())
		{
			throw new NoSuchElementException();
		}
		
		return elements.get(1);
	}

	@Override
	public Element pop() {
			
		if(isEmpty())
		{
			throw new NoSuchElementException();
		}
		
		Collections.swap(elements, 1, elements.size() - 1);
		Element temp = elements.remove(elements.size() - 1);
		if(!isEmpty())
		{
			percolatDown(1);
		}
		
		return temp;
	}

	@Override
	public int size() {
		
		return elements.size() - 1;
	}

	@Override
	public void update(int index) {
		percolateUp(index);
		percolatDown(index);
		
	}

	@Override
	public ArrayList<Element> toArrayList() {
		
	
		ArrayList<Element> copy = new ArrayList<>();
		elements.forEach(value -> copy.add(value));
	   
		return copy;
	}

}
