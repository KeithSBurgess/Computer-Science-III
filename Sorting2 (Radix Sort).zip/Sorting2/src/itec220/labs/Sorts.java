package itec220.labs;


public class Sorts {
	
	
	public interface SortType {
		void integerSort(int[] sort);
	}
	
	
	
	/*
	 * Method finds the smallest number in the given array
	 */
	public static int findMin(int[] sort) {
		int min = sort[0];
		for(int i=0;i<sort.length;i++) {				
			if(sort[i] < min) {
				min = sort[i];
			}
		}
		return min;
	} //END findMin
	
	/*
	 * Method finds the biggest number in the given array
	 */
	public static int findMax(int[] sort) {
		int max = sort[0];
		for(int i=0;i<sort.length;i++) {				
			if(sort[i] > max) {
				max = sort[i];
			}
		}
		return max;
	} //END findMAX
	
	/*
	 * Method counts the number of occurrences of the given index number
	 */
	/*public static int countMethod(int[] sort,int index) {
		int x = 0;
		int size = sort.length;

			for(int j=0;j<size;j++) {				
				if(sort[j] == index) {
					x++;
				}
			}
		
		return x;
	} //END countMethod
	*/
	
	/*
	 * Method sorts the 'sort array' given the countList array
	 */
	public static void sortMethod(int[] sort,int[] countList,int[] sortedArray) {
		int num;
		int index;
		for(int i=sort.length-1;i>=0;i--) { //[starting from rear]
			num = sort[i];						//num is the number in the 'sort' array (used to reference index)
			index = countList[num]-1;			//index is the new sorted index for given num
			sortedArray[index] = num;			//stores number in its correctly sorted index
			countList[num] = index;				//store decremented index			
		}
		
		for(int i=0;i<sort.length;i++) {
			sort[i] = sortedArray[i];
		}
		
	} //END sortMethod
	
	/*
	 * START of countingSort
	 */
	public static void countingSort(int[] sort)
	{
		int size;
		int min;
		int max;
		
		size = sort.length;		
		min = findMin(sort);
		max = findMax(sort);		
		size = (max-min)+1;
		
		int[] countList = new int [size];	//Declaring new array of length 'size' to store counts
		
		/*(int i=0;i<size;i++) {
			countList[i] = countMethod(sort,i); //countMethod Call

		}*/
		
		//counts how many times each number occurs
        for (int i = 0; i < sort.length; i++) {
            int current = sort[i] - min;
            countList[current] += 1 ;
        }
		
		
		for(int i=0;i<size-1;i++) {		//Adjusts countList (by adding counts) for sorting
			countList[i+1] = countList[i] + countList[i+1];
		}
		
		int[] sortedArray = new int [size]; //Creates new array to store sorted data
		sortMethod(sort,countList,sortedArray);	//sortMethod Call

		

	} //END countingSort
	
	
	//------------------------------------------------------------------------------------
	
	
	/*
	 * Method sorts the 'sort array' given the countList array
	 */
	public static void sortDigitMethod(int[] sort,int[] countList,int size,int divideBy) {
		int num;
		int index;
		int[] sortedArray = new int [size]; //Creates new array to store sorted data
		
		for(int i=sort.length-1;i>=0;i--) { 	//[starting from rear]
			num = (sort[i]/divideBy)%10;		//num is the number in the 'sort' array (used to reference index)
			index = countList[num]-1;			//index is the new sorted index for given num
			sortedArray[index] = sort[i];		//stores number in its correctly sorted index
			countList[num] = index;				//store decremented index			
		}
		
		for(int i=0;i<sort.length;i++) {	//Updates sort array
			sort[i] = sortedArray[i];
		}
		
	} //END sortdigitMethod
	
	
	
	public static void radixSort(int[] sort)
	{	
		int temp;
		int size;
		int min;
		int max;
		int digits = 0; //counts the max number of digits [loop counter]
		int divideBy = 1;
		
		size = sort.length;		
		min = findMin(sort);
		max = findMax(sort);		
		size = (max-min)+1;
		temp = max;
		
		while(temp>0) {	//gets max number of digits
			temp /= 10;
			digits++;
		}
		

		//Loops through each digit
		while(digits > 0) {
			
			int[] countList = new int [10];	//Declaring new array of length 10 to store counts of digits	

			
			//counts how many times each number occurs
	        for (int i = 0; i < sort.length; i++) {
	            int current = (sort[i]/divideBy)%10;
	            countList[current] += 1 ;
	        }
			
			
			for(int i=0;i<10-1;i++) {		//Adjusts countList (by adding counts) for sorting
				countList[i+1] = countList[i] + countList[i+1];
			}
	        
			sortDigitMethod(sort,countList,size,divideBy);	//sortDigitMethod Call
			
			digits--;		//Update loop counter
			divideBy *= 10;	//Update divideBy

		} //END while loop
		
	}//END radixSort
	
}