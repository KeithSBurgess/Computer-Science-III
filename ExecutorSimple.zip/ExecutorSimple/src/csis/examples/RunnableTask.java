package csis.examples;

public class RunnableTask implements Runnable {

	@Override
	public void run() {
		
		System.out.println("Hello From Differnt Thread");

	}

}
