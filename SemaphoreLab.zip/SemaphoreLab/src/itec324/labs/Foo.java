package itec324.labs;

public class Foo {

	
	public void first() { 
		System.out.print("first"); 
	
	}
	public void second() {
		
		System.out.print("second");
		
		
	}
	public void third() { 
		
		System.out.print("third"); 
		
	}
}
