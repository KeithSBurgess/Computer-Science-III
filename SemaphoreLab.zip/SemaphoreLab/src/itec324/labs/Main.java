package itec324.labs;
public class Main {

	public static void main(String[] args) {
		
		Foo foo = new Foo();
		// Lambda Runnable
		Runnable task1 = () -> { try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				} foo.first(); };
		
		// Lambda Runnable
		Runnable task2 = () -> { try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		} foo.second(); };
		
		// Lambda Runnable
		Runnable task3 = () -> { foo.third(); };
		
		Thread three = new Thread(task3);
		Thread one = new Thread(task1);
		Thread two = new Thread(task2);
				
		one.start();
		two.start();
		three.start();
		

	}

}
