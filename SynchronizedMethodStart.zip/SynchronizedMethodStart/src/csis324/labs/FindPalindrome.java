package csis324.labs; 
import java.util.function.Consumer;

public class FindPalindrome implements Runnable {

	private Consumer<String> consumer;
	private long start = 0;
	private long end = 0;

	public FindPalindrome(Consumer<String> consumer, long start, long end) {
		super();
		this.consumer = consumer;
		this.start = start;
		this.end = end;
	}

	@Override
	public void run() {

		// Go from start to end and if the number is a palidrome
		// call consumer.accept on it (must be a string) hint: "" + i
		

	}

	private boolean isPaladrome(long number) {
	
		return true;
	}

}
