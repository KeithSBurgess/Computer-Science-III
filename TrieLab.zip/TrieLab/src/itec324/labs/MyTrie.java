package itec324.labs;

import java.util.ArrayList;

@SuppressWarnings("unused")
public class MyTrie implements Trie {

	
	private TrieNode root = new TrieNode(false, null);
	
	private class TrieNode
	{
		private boolean validString;
		private TrieNode parent;
		private int currentIndex = 0;
		private TrieNode nodes[] = new TrieNode[26];
				
		public TrieNode(boolean validString, TrieNode parent)
		{
				this.validString = validString;
				this.parent = parent;
		}					

	};
	
	
	@Override
	public void insert(String insert) {
		
	
	}
	
	@Override
	public boolean contains(String find) {
		
		throw new UnsupportedOperationException();
		//return false;
	}

	@Override
	public ArrayList<String> getSorted() {
			
		throw new UnsupportedOperationException();
		
	}
	// Hint this will make your life easier!
	private ArrayList<String> getSubTree(TrieNode t, String prefix ) {
		throw new UnsupportedOperationException();
	}

	@Override
	public ArrayList<String> startsWith(String prefix) {
		throw new UnsupportedOperationException();
	}
	

}
