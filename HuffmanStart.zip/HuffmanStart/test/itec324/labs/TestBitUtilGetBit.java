package itec324.labs;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBitUtilGetBit {

	@Test
	void test0() {
			
		boolean actual = BitUtil.getBit((byte)0, 0);
		assertFalse(actual);
	}
	
	@Test
	void test0False() {
		
		boolean actual = BitUtil.getBit((byte)1, 0);
		assertTrue(actual);
	}
	
	@Test
	void test1True() {
		
		boolean actual = BitUtil.getBit((byte)2, 1);
		assertTrue(actual);
	}
	
	@Test
	void test1False() {
		
		boolean actual = BitUtil.getBit((byte)0, 1);
		assertFalse(actual);
	}
	
	@Test
	void test2True() {
		
		boolean actual = BitUtil.getBit((byte)4, 2);
		assertTrue(actual);
	}
	
	@Test
	void test2False() {
		
		boolean actual = BitUtil.getBit((byte)0, 2);
		assertFalse(actual);
	}
	
	@Test
	void test3True() {
		
		boolean actual = BitUtil.getBit((byte)8, 3);
		assertTrue(actual);
	}
	
	@Test
	void test3False() {
		
		boolean actual = BitUtil.getBit((byte)0, 3);
		assertFalse(actual);
	}

	@Test
	void test4True() {
		
		boolean actual = BitUtil.getBit((byte)16, 4);
		assertTrue(actual);
	}
	
	@Test
	void test4False() {
		
		boolean actual = BitUtil.getBit((byte)0, 4);
		assertFalse(actual);
	}
	
	@Test
	void test5True() {
		
		boolean actual = BitUtil.getBit((byte)32, 5);
		assertTrue(actual);
	}
	
	@Test
	void test5False() {
		
		boolean actual = BitUtil.getBit((byte)0, 5);
		assertFalse(actual);
	}
	
	@Test
	void test6True() {
		
		boolean actual = BitUtil.getBit((byte)64, 6);
		assertTrue(actual);
	}
	
	@Test
	void test6False() {
		
		boolean actual = BitUtil.getBit((byte)0, 6);
		assertFalse(actual);
	}
	
	@Test
	void test7True() {
		
		boolean actual = BitUtil.getBit((byte)128, 7);
		assertTrue(actual);
	}
	
	@Test
	void test7False() {
		
		boolean actual = BitUtil.getBit((byte)0, 7);
		assertFalse(actual);
	}
	

	
}
