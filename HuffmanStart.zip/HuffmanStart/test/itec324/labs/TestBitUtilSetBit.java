package itec324.labs;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBitUtilSetBit {

	@Test
	void test0() {
			
		byte actual = BitUtil.setBit((byte)0, 0);
		assertEquals(actual,1);
	}
	
	
	
	@Test
	void test1() {
		
		byte actual = BitUtil.setBit((byte)0, 1);
		assertEquals(actual,2);
	}
	
	@Test
	void test2() {
		
		byte actual = BitUtil.setBit((byte)0, 2);
		assertEquals(actual,4);
	}
	
	@Test
	void test3() {
		
		byte actual = BitUtil.setBit((byte)0, 3);
		assertEquals(actual,8);
	}
	
	@Test
	void test4() {
		
		byte actual = BitUtil.setBit((byte)0, 4);
		assertEquals(actual,16);
	}
	@Test
	void test5() {
		
		byte actual = BitUtil.setBit((byte)0, 5);
		assertEquals(actual,32);
	}
	
	@Test
	void test6() {
		
		byte actual = BitUtil.setBit((byte)0, 6);
		assertEquals(actual,64);
	}
	
	// Add code for test 7
	@Test
	void test7() {
		
		fail();
	}

	
}
