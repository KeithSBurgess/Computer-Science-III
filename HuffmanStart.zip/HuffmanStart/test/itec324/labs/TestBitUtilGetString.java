package itec324.labs;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBitUtilGetString {

	@Test
	void test0() {
		
		String expected = "00000000";
		String actual = BitUtil.getBitString((byte) 0);
		assertEquals(expected,actual);
	}
	
	@Test
	void test1() {
		
		String expected = "00000001";
		String actual = BitUtil.getBitString((byte) 1);
		assertEquals(expected,actual);
	}
	
	@Test
	void test2() {
		
		String expected = "00000010";
		String actual = BitUtil.getBitString((byte) 2);
		assertEquals(expected,actual);
	}
	
	
	@Test
	void test3() {
		
		String expected = "00000011";
		String actual = BitUtil.getBitString((byte) 3);
		assertEquals(expected,actual);
	}
	

	@Test
	void test4() {
		
		String expected = "00000100";
		String actual = BitUtil.getBitString((byte) 4);
		assertEquals(expected,actual);
	}

	@Test
	void test5() {
		
		String expected = "00000101";
		String actual = BitUtil.getBitString((byte) 5);
		assertEquals(expected,actual);
	}
	@Test
	void test6() {
		
		String expected = "00000110";
		String actual = BitUtil.getBitString((byte) 6);
		assertEquals(expected,actual);
	}
	@Test
	void test7() {
		
		String expected = "00000111";
		String actual = BitUtil.getBitString((byte) 7);
		assertEquals(expected,actual);
	}
	@Test
	void test8() {
		
		String expected = "00001000";
		String actual = BitUtil.getBitString((byte) 8);
		assertEquals(expected,actual);
	}
	
	@Test
	void test9() {
		
		String expected = "00001001";
		String actual = BitUtil.getBitString((byte) 9);
		assertEquals(expected,actual);
	}
	
	@Test
	void test10() {
		
		String expected = "00001010";
		String actual = BitUtil.getBitString((byte) 10);
		assertEquals(expected,actual);
	}
	
	
	@Test
	void test11() {
		
		String expected = "00001011";
		String actual = BitUtil.getBitString((byte) 11);
		assertEquals(expected,actual);
	}
	

	@Test
	void test12() {
		
		String expected = "00001100";
		String actual = BitUtil.getBitString((byte) 12);
		assertEquals(expected,actual);
	}

	@Test
	void test13() {
		
		String expected = "00001101";
		String actual = BitUtil.getBitString((byte) 13);
		assertEquals(expected,actual);
	}
	@Test
	void test14() {
		
		String expected = "00001110";
		String actual = BitUtil.getBitString((byte) 14);
		assertEquals(expected,actual);
	}
	@Test
	void test15() {
		
		String expected = "00001111";
		String actual = BitUtil.getBitString((byte) 15);
		assertEquals(expected,actual);
	}
}
