package itec324.labs;

public class BitUtil {
	
	
	private final static byte BITMASK[] = { 0b0000_0001 , 0b0000_0010 , 0b0000_0100, 0b0000_1000,  
			                                0b0001_0000 , 0b0010_0000 , 0b0100_0000, (byte)0b1000_0000 };
	/**
	 creates a string of 1's and 0s characters that match the bits of the given byte

	@param the byte to create a string representation of
	
	@return the string the represents bytes
	*/

	public  static String getBitString(byte convert )
	{
		StringBuilder sb = new StringBuilder();
		// add code to add to string builder
		
		return sb.toString();
		
	}
	
	
	/**
	 Set a specified bit in the input byte

	@param the byte to set a bit of
	
	@param the bit to set 
	
	@return the byte with the bit indicated set on
	*/

	public  static byte setBit(byte input , int bitToSet)
	{
		// use Bitmask to set bit
		// fix this line
		return (byte) input ;
		
	}
	
	
	/**
	 clear a string of 1's and 0s characters that match the bits of the given byte

	@param the byte to clear bit of
	
	@param the bit to clear 
	
	@return the byte with the bit indicated set off
	*/

	public  static byte clearBit(byte input , int bitToSetOff)
	{
		// use Bitmask to set bit
		// fix this line hint cast (byte) is needed 
		return  (byte) input ;
		
	}
	
	/**
	 check if the specified bit is on in the given byte

	@param the byte to check if a given bit is on in
	
	@param the bit to check 
	
	@return true if the byte has the indicate bit set on false if it is not
	*/

	public  static boolean getBit(byte input , int bitToCheck)
	{
		return false;
		
	}
}
