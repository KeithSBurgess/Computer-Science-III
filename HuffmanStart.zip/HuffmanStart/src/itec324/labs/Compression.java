package itec324.labs;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.PriorityQueue;

public class Compression {

	private Node root = null;
	private HashMap<Character, String> codes;
	
	private class Node implements Comparable<Node> {

		public String letters = new String();
		public int frequency = 0;
		public Node left;
		public Node right;

		public Node(String letter, int frequency) {
			this.letters = letter;
			this.frequency = frequency;
		}
		public Node(Node left, Node right) {
			this.letters = left.letters + right.letters;
			this.frequency = left.frequency + right.frequency;
			this.left = left;
			this.right = right;
		}

		@Override
		public int compareTo(Node o) {
			
			return this.frequency - o.frequency;
		}

		@Override
		public String toString() {
			return "Node [letters=" + letters + ", frequency=" + frequency + "]";
		}

	}
	
	public Compression(String fileName) {

		char[] filebuffer = FileUtility.readFiletoBuffer(fileName); 
		root = buildTree(filebuffer);
		loadCodes();

	}
	
	public Node buildTree(char[] filebuffer)  {
		int[] counts = getFrequencies(filebuffer);
		PriorityQueue<Node> nodes = createNodes(counts);
		return createTree(nodes);		
		
	}
	
	private void loadCodes() {
		codes = new HashMap<Character, String>();
		loadCodes(root, "");
	}

	// Walk the Huffman tree add character code to the hashmap 
	// note recursive call
	// think about a binary tree
	// how do you know to add a code
	// code is the code to get to this node 
	// ("0 for left")
	// ("1 for right")
	// for example if I went  L L R my code should be "110"
	private void loadCodes(Node node, String code) {
		
		
		//Add code 
	} 



	// given a PriorityQueue of nodes
	// Create a Huffman tree
	private Node createTree(PriorityQueue<Node> nodes)
	{
		//Add code 
		return nodes.remove();
	}
	// given a list of count create a PriorityQueue of nodes
	// the index of the count is the character code
	private PriorityQueue<Node> createNodes(int counts[])
	{
		PriorityQueue<Node> nodes = new PriorityQueue<>();
		
		//Add code 
		 return nodes;
	}
	
	// for every character in the buffer get its frequency
	// think about counting sort
	private int[] getFrequencies(char[] buffer) {
		
		int frequencies[] = new int[65_536];
		//Add code 
		return frequencies;
	}
	/**
	prints the tree inorder. Prints both the characters and frequency
	
	@return No return value
	*/
	public void printTree() {
	
		printTree(root, "");
	}
	// Walk the Huffman tree add character code to the hashmap 
	// note recursive call
	// think about a binary tree
	// how do you know to add a code
	// code is the code to get to this node 
	// ("0 for left")
	// ("1 for right")
	// for example if I went  L L R my code should be "110"
	private void printTree(Node c, String code)
	{
		//Add code 
	}
	
	/**
	decodes the contents of the compressed file
	and saves its de-compressed form in the target file 
	file should contain valid Huffman prefix codes 
	in the form of binary (NOT text values 0 and 1)	

	@param outputFileName -the file name to save the uncompressed version 
	@param inputFileName -the compressed file to uncompress. 
	
	@return true if the operation was successful
	*/
	public boolean uncompressFile(String inputFileName, String outputFileName) {

		Node currentNode = root;		
		byte allBytes[] = FileUtility.readAllBytes(inputFileName);
		
		System.out.println(allBytes.length);
		StringBuilder fileContents = new StringBuilder();
		for (byte currentByte : allBytes) {
			//Add code 

		}			
		return FileUtility.writeToFile(outputFileName, fileContents.toString());
		
	}
	
	
	
	/**
	compresses the contents of the inputFileName
	and saves its compressed form in the output file
	file should contain valid Huffman prefix codes
	in the form of binary (NOT text values 0 and 1)

	@param outfileName -the filename to  save the compressed version as
	@param inputFileName -the file to store
	

	@return true if the operation was successful
	*/
	public boolean compressFile(String outfileName, String inputFileName) {

		int bitNumber = 0;		
		char[] filebuffer = FileUtility.readFiletoBuffer(inputFileName); 
		ByteArrayOutputStream output = new ByteArrayOutputStream();

		byte saveByte = 0;
		for (char current :filebuffer) {
			String code = codes.get(current);
			for (int i = 0; i < code.length(); i++) {
				//Add code 

			}

		}
		if (bitNumber != 0) {
			output.write(saveByte);
		}

		byte[] out = output.toByteArray();
		return FileUtility.writeSmallBinaryFile(out, outfileName);
	
	}

	

}
