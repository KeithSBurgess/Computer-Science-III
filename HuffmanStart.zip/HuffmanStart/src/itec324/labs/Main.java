package itec324.labs;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Compression c = new Compression("resources/Bigo.txt");		
		c.printTree();		
		c.compressFile("resources/output/test.comp","resources/Bigo.txt");
		c.uncompressFile("resources/output/test.comp","resources/output/test.txt");
      
	}

}
