package itec220.labs;


public class Sorts {
	
	
	public interface SortType {
		void integerSort(int[] sort);
	}
	
	public static void countingSort(int[] sort)
	{
		
	}
	
	public static void radixSort(int[] sort)
	{
		
	}
	
}