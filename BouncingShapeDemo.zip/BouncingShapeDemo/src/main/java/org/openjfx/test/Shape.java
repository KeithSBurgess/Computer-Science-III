package org.openjfx.test;

import java.util.Random;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public abstract class Shape {
	private int x = 0;
	private int y = 0;
	// Indicates direction of motion in Horizontal axis 
	// +1 Right -1 Left
	private int xDir = 1;
	// Indicates direction of motion in Vertical axis 
	// +1 Down -1 Up
	private int yDir = 1;

	private Color color;	
	private static int DEFAULT_WIDTH = 500;
	private static int DEFAULT_HEIGHT = 500;
	private static int MAX_WIDTH = 100;
	private static int MIN_WIDTH = 20;
	private static int MAX_HEIGHT = 100;
	private static int MIN_HEIGHT = 20;
	
	
	// width of shape
	private double width = 0;
	// height of shape
	private double height = 0;
	// width of Window
	private int windowWidth = 0;
	// height of Window
	private int windowHeight = 0;
	
	private static Random random = new Random();
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}	
	public Color getColor() {
		return color;
	}
	public double getWidth() {
		return width;
	}
	public double getHeight() {
		return height;
	}

	public Shape(int windowWidth, int windowHeight, boolean widthHeightEqual )
	{
		this();
		this.windowWidth = windowWidth ;
		this.windowHeight = windowHeight ;
		if(widthHeightEqual)
		{
			this.height = width;
			this.x = random.nextInt(windowHeight - (int)height);		
		}
		
	}
	public Shape() {
		super();
		
		this.windowWidth = DEFAULT_WIDTH;
		this.windowHeight = DEFAULT_HEIGHT;
		this.width  = Math.max(random.nextDouble() * MAX_WIDTH, MIN_WIDTH) ;
		this.height = Math.max(random.nextDouble() * MAX_HEIGHT, MIN_HEIGHT);
		
		this.y = random.nextInt(windowHeight -  100); 
		this.x = random.nextInt(windowWidth -  100);		
		this.xDir = random.nextBoolean() ? 1 : -1;
		this.yDir = random.nextBoolean() ? 1 : -1;
		this.color = Color.color(Math.random(), Math.random(),Math.random());
		
	}

		
		
	public void update() {
		if( x + width > windowWidth|| x < 0)
		{
			System.out.printf("H %d %f %d%n",x , height, windowHeight);
			xDir *= -1;
		}
		if( y + height > windowHeight || y < 0)
		{
			System.out.printf("W %d %f %d%n",y , width, windowWidth);
			yDir *= -1;
		}
		x += 1 * xDir;
		y += 1 * yDir;
		
	}
	
	public abstract void draw(GraphicsContext gc);		
		
}
