package itec324.labs;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestBitUtilClearBit {

	@Test
	void test0() {
			
		byte actual = BitUtil.clearBit((byte)1, 0);
		assertEquals(actual,0);
	}
	
	
	
	@Test
	void test1() {
		
		byte actual = BitUtil.clearBit((byte)2, 1);
		assertEquals(actual,0);
	}
	
	@Test
	void test2() {
		
		byte actual = BitUtil.clearBit((byte)4, 2);
		assertEquals(actual,0);
	}
	
	@Test
	void test3() {
		
		byte actual = BitUtil.clearBit((byte)8, 3);
		assertEquals(actual,0);
	}
	
	@Test
	void test4() {
		
		byte actual = BitUtil.clearBit((byte)16, 4);
		assertEquals(actual,0);
	}
	@Test
	void test5() {
		
		byte actual = BitUtil.clearBit((byte)32, 5);
		assertEquals(actual,0);
	}
	
	@Test
	void test6() {
		
		byte actual = BitUtil.clearBit((byte)64, 6);
		assertEquals(actual,0);
	}
	
	// Add code for test 7
	@Test
	void test7() {
		
		byte actual = BitUtil.clearBit((byte)-128, 7);
		assertEquals(actual,0);
	}

	
}
