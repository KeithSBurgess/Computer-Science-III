package itec324.labs;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Compression c = new Compression("resources/Bigo.txt");		
		//c.printTree();		
		Boolean compressionSuccess = c.compressFile("resources/output/test.comp","resources/Bigo.txt");
		System.out.println("Compression: " + compressionSuccess);
		Boolean deCompressionSuccess = c.uncompressFile("resources/output/test.comp","resources/output/test.txt");
		System.out.println("deCompression: " + deCompressionSuccess);
      
	}

}
