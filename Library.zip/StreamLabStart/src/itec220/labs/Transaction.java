package itec220.labs;
/**
 * 
 */



import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author rober
 *
 */
public class Transaction {
	
	
	private Integer ID;
	private Book book;
	private Patron patron;
	private LocalDateTime date;
	private TransactionType type;
	private BigDecimal amount;
	private static final DateTimeFormatter transationDateFormat =  DateTimeFormatter.ISO_LOCAL_DATE_TIME;
	
	public Book getBook() {
		return book;
	}
	public Patron getPatron() {
		return patron;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public TransactionType getType() {
		return type;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public double getAmountasDouble() {
		return amount.doubleValue();
	}
	
	
	
	/**
	 * @param book
	 * @param patron
	 * @param date
	 * @param type
	 * @param amount
	 */
	public Transaction(Book book, Patron patron, LocalDateTime date, TransactionType type, BigDecimal amount) {
		this.book = book;
		this.patron = patron;
		this.date = date;
		this.type = type;
		this.amount = amount;
	}
		/**
	 * @param book
	 * @param patron
	 * @param date
	 * @param type
	 * @param amount
	 */
	public Transaction(Book book, Patron patron, String date, TransactionType type, BigDecimal amount) {
		this.book = book;
		this.patron = patron;
		this.date = LocalDateTime.parse(date, transationDateFormat);
		this.type = type;
		this.amount = amount;
	}
	/**
	 * @param book
	 * @param patron
	 * @param date
	 * @param type
	 * @param amount
	 */
	public Transaction(Book book, Patron patron, TransactionType type, BigDecimal amount) {
		this.book = book;
		this.patron = patron;
		this.date = LocalDateTime.now();
		this.type = type;
		this.amount = amount;
	}
	

		
	public Transaction(Book book, Patron patron,  TransactionType type) {
		this.book = book;
		this.patron = patron;
		this.date = LocalDateTime.now();
		this.type = type;
	}
	
	public Transaction(BigDecimal amount, Patron patron,  TransactionType type) {
		this.book = null;
		this.amount = amount;
		this.patron = patron;
		this.date = LocalDateTime.now();
		this.type = type;
	}
	
	public Transaction(Patron patron,  TransactionType type) {
		this.book = null;
		this.patron = patron;
		this.amount = null;
		this.date = LocalDateTime.now();
		this.type = type;
	}
	public Integer getId() {
		return ID;
	}
	public void setId(Integer iD) {
		ID = iD;
	}
	

}
