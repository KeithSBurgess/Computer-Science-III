package itec220.labs;
/**
 * 
 */


import java.math.BigDecimal;

/**
 * @author robward
 *
 */
public class Patron {
	
	private String firstName;
	private String lastName;
	private String cardNumber;
	private BigDecimal feesOwed;
	/**
	 * @param firstName
	 * @param lastName
	 * @param cardNumber
	 * @param feesOwed
	 */
	public Patron(String firstName, String lastName, String cardNumber, BigDecimal feesOwed) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.cardNumber = cardNumber;
		this.feesOwed = feesOwed;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the cardNumber
	 */
	public String getCardNumber() {
		return cardNumber;
	}
	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	/**
	 * @return the feesOwed
	 */
	public boolean owesFee() {
		return (feesOwed.compareTo(BigDecimal.ZERO) > 0) ;
	}
	
	/**
	 * @return the feesOwed
	 */
	public BigDecimal getFeesOwed() {
		return feesOwed;
	}
	/**
	 * @param feesOwed the feesOwed to set
	 */
	public void setFeesOwed(BigDecimal feesOwed) {
		this.feesOwed = feesOwed;
	}

}
