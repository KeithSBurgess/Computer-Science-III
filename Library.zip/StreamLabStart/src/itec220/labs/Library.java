package itec220.labs;
/**
 * 
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.stream.Collectors;


/**
 * @author robert
 *
 */
public class Library {

	private ArrayList<Patron> patrons = new ArrayList<>();
	private ArrayList<Book> books= new ArrayList<>();
	private ArrayList<Transaction> transactions= new ArrayList<>();
		
	/**
	 * 
	 */
	public Library() {
	}

	private ArrayList<String> readFile(String fileName)
	{
		ArrayList<String> lines = new ArrayList<String>();
		
		
		BufferedReader br = null;
		FileReader fr = null;

		try {

			
			fr = new FileReader(fileName);
			br = new BufferedReader(fr);

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				lines.add(sCurrentLine);
				
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		
		return lines;
	}
	
	/**
	 * 
	 */
	public Library(String patronFile, String bookFile) {
		
		ArrayList<String> patronLines = readFile(patronFile);
		for (String string2 : patronLines) {
			
			String[] parts = string2.split(",");
		
			patrons.add(new Patron(parts[0], parts[1], parts[2], new BigDecimal(Double.parseDouble(parts[3]))));
			
		} 
		
		ArrayList<String> bookLines = readFile(bookFile);
		for (String string2 : bookLines) {
		
			String[] parts = string2.split(",");
		
			
			books.add(new Book(BookGenre.valueOf(parts[5]), parts[3], parts[1], parts[0], parts[6],  parts[4], Boolean.parseBoolean(parts[7]) , parts[2]));
			
		} 
		
	}

	
	public void addPatron( Patron patron)
	{
		patrons.add(patron);
	}
	
	public void addBook( Book book)
	{
		books.add(book);
	}
	/**
	   * Get all books  whose author last name is the given string.
	   * @param String lastName- Author whose last name to search for
	   * @return ArrayList<Book> A list of the books  found 
	   * 	   
	   * */
	
	public ArrayList<Book> getBooksbyAuthor(String lastName)
	{
		ArrayList<Book> bookAuthor = books.stream()
									.filter((b) -> { return b.getAuthorLastName().equals(lastName);  })	
									.collect(Collectors.toCollection(ArrayList::new));
		return bookAuthor;
	}
	
	/**
	   * Finds all titles starting with the given letter.
	   * @param char letter- the charter we are looking for
	   * as the first letter in the title
	   * @return ArrayList<String> A list of the title of the books as strings 
	   * 	   
	   * */
	public ArrayList<String> getTitlebyFirstLetterTitle(char letter)
	{
		 //.collect(Collectors.toCollection(ArrayList::new));
				
		return new ArrayList<String>();
	}

	/**
	   * Get last name of Authors who wrote any book of the specified genre.
	   * Names should be in Alphabetical order with no duplicates.
	   * @param BookGenre the genre to search for Authors of
	   * @return ArrayList<String> A list of the authors  found 
	   * 	   
	   * */
	public ArrayList<String> getAuthorsWithGenreDistinctSorted(BookGenre genre)
	{
		
		
		
		return new ArrayList<String>();
	}
	/**
	   * Get last name of any Patron  who owes a fee.
	   * Names should be sorted alphabetically by last name.
	   * @return ArrayList<String> A list of last names of patrons found 
	   * 	   
	   * */
	public ArrayList<String> getLastNamePatronWithFeesSorted()
	{
	      return new ArrayList<String>();
	}
	/**
	   * Get last names of  patrons  who owes more than the specified amount.
	   * Names should be sorted  by amounted owed.
	   * @param double fee - amount over which to search on
	   * @return ArrayList<String> A list of last names of patrons found 
	   * 	   
	   * */
	public ArrayList<String> getLastNamePatronWithFeesGreaterSortedbyFee(Double fee)
	{
		
		return new ArrayList<String>();
	}
	
	/**
	   * Get last names of  patrons  with the highest fees up to the number indicate
	   * For example if 3 is the limit get the top three *
	   *  @param int limit number of patrons to find - 
	   *  @return ArrayList<String> A list of last names of patrons found 
	   * 	   
	   * */
	
	public ArrayList<String> getCardNumberPatronTopFees(int limit)
	{
		return new ArrayList<String>();
	}
	/**
	   * Get title  of all books checked out.
	   * Sort books by ISBN.
	  
	   * @return ArrayList<String> A list of the titles  found 
	   * 	   
	   * */
	public ArrayList<String> getCheckedoutTitlesSortbyISBN()
	{
		
		return new ArrayList<String>();
	}
	/**
	   * Get Patrons the start with the given string.
	   * Names should be in Alphabetical order 
	   * For example if "P" were the string find all patrons 
	   * whose last name start with P
	   * @param startsWith prefix to search for
	   * @return ArrayList<String> A list of the patrons  found 
	   * 	   
	   * */
	public ArrayList<String> getPatronsLastNameStartsWithSortedName(String startsWith)
	{
		
		return new ArrayList<String>();
	}
	
	/**
	   * Get Patrons whose card number starts with the given string.
	   * Names should be in Alphabetical order 
	   * For example if "1" were the string find all patrons 
	   * whose card number started  start with 1
	   * @param startsWith prefix to search for
	   * @return ArrayList<String> A list of the patrons  found 
	   * 	   
	   * */
	  
	
	public ArrayList<String> getPatronsLastNameWithCardNumberStartsWithSortedByName(String startsWith)
	{
		
		return new ArrayList<String>();
	}
	
}
