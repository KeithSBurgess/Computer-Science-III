package itec220.labs;
/**
 * 
 */


/**
 * @author robward
 *
 */
public enum BookGenre {

	ComputerScience, ScienceFiction, Satire, Drama, Action, Romance, 
	Mystery, Horror, Health, Guide, Travel, Children, Religion, Science,
	History, Math, Anthology, Poetry, Encyclopedias, Dictionaries,
	Comics, Art, Cookbooks, Diaries, Journals, Series, Trilogy,
	Biographies , Autobiographies, Fantasy

}
