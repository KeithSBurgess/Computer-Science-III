package itec220.labs;
/**
 * 
 */


/**
 * @author rober
 *
 */
public enum TransactionType {
	
	PaidFee, ChargedFee, BookCheckout, BookCheckin, MemberCreated, BookAdded

}
