package itec220.labs;
/**
 * 
 */


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * @author robward
 *
 */
public class Book implements Comparable<Book> {
	
	private BookGenre genre;
	private String ISBN;
	private String authorLastName;
	private String authorFirstName;
	private String bookId;
	private LocalDate  publicationDate;
	private Boolean checkedOut;
	private String title;
	private static final DateTimeFormatter publicationDateFormat =  DateTimeFormatter.ISO_LOCAL_DATE;

	
	
	
	
	


	@Override
	public String toString() {
		return "Book ID:" + bookId + " ISBN:" + ISBN + ", " + authorLastName + ", " + title + "]";
	}


	/**
	 * @param genre
	 * @param iSBN
	 * @param authorLastName
	 * @param authorFirstName
	 * @param bookId
	 * @param publicationDate
	 * @param checkedOut
	 * @param title
	 */
	public Book(BookGenre genre, String iSBN, String authorLastName, String authorFirstName, String bookId,
			String publicationDate, Boolean checkedOut, String title) {
		this.genre = genre;
		ISBN = iSBN;
		this.authorLastName = authorLastName;
		this.authorFirstName = authorFirstName;
		this.bookId = bookId;
		this.publicationDate = LocalDate.parse(publicationDate, publicationDateFormat);
		this.checkedOut = checkedOut;
		this.title = title;
	}


	/**
	 * @param genre
	 * @param iSBN
	 * @param authorLastName
	 * @param authorFirstName
	 * @param bookId
	 * @param publicationDate
	 * @param checkedOut
	 * @param title
	 */
	public Book(BookGenre genre, String iSBN, String authorLastName, String authorFirstName, String bookId,
			LocalDate publicationDate, Boolean checkedOut, String title) {
		this.genre = genre;
		ISBN = iSBN;
		this.authorLastName = authorLastName;
		this.authorFirstName = authorFirstName;
		this.bookId = bookId;
		this.publicationDate = publicationDate;
		this.checkedOut = checkedOut;
		this.title = title;
	}
	
	

	public Boolean getCheckedOut() {
		return checkedOut;
	}


	public void setCheckedOut(Boolean checkedOut) {
		this.checkedOut = checkedOut;
	}


	public BookGenre getGenre() {
		return genre;
	}


	public String getISBN() {
		return ISBN;
	}


	public String getBookId() {
		return bookId;
	}


	public LocalDate getPublicationDate() {
		return publicationDate;
	}


	public String getTitle() {
		return title;
	}


	public String getAuthorLastName() {
		return authorLastName;
	}

	public String getAuthorFirstName() {
		return authorFirstName;
	}


	@Override
	public int compareTo(Book o) {
		// TODO Auto-generated method stub
		return 0;
	}


	
	

}
