package itec220.labs;


public class Main {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		Library library = new Library("patrons.txt", "books.txt");
//		
//	    library.getBooksbyAuthor("Seuss").forEach(System.out::println);
//	    
//	    library.getTitlebyFirstLetterTitle('T').forEach(System.out::println);
//	
//	    library.getAuthorsWithGenreDistinctSorted(BookGenre.Comics).forEach(System.out::println);
//	    
//	    library.getLastNamePatronWithFeesSorted().forEach(System.out::println);
	    
//	    library.getLastNamePatronWithFeesGreaterSortedbyFee(Double.valueOf(10)).forEach(System.out::println);
	    
//	    library.getCardNumberPatronTopFees(3).forEach(System.out::println);
		
//		library.getCheckedoutTitlesSortbyISBN().forEach(System.out::println);
		
//		library.getPatronsLastNameStartsWithSortedName("Br").forEach(System.out::println);
	
		
		//library.getPatronsLastNameWithCardNumberStartsWithSortedByName("2").forEach(System.out::println);
		
		
	}
	

}
