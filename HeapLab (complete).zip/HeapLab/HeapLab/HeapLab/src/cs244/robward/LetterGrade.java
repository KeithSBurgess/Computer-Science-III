package cs244.robward;

public enum LetterGrade {
	
	A,B,C,D,F

}
